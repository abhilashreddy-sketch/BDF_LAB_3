# Aurora University — Backend Development Fundamentals (BDF)
## Lab 3: REST API Development, Query Parameters, Request Validation & Debugging

**Student Name:** Appampally Abhilash Reddy  
**Registration Number:** 252U1R5008  
**Course:** B.Tech CSE (Year II, Term II / IV Semester)  
**Faculty Evaluator:** Joel Prashanth D  
**Academic Year:** 2025–2026  

---

## 1. Project Overview
This repository contains the complete implementation for BDF Lab 03. It transitions previous Lab 2 concepts into a production-standard REST API managing a library book catalog backed by SQLite3.

### Features
- **RESTful Endpoints:** Complete CRUD implementation (`GET /books`, `GET /books/:id`, `POST /books`, `PUT /books/:id`, `DELETE /books/:id`).
- **Query Parameters:**
  - `search_q`: Partial title matching using SQL `LIKE`.
  - `order_by` & `order`: Allowlisted column sorting (`id`, `title`, `author`, `price`) in `ASC` or `DESC`.
  - `limit` & `offset`: Pagination controls.
  - `min_price` & `max_price`: Numerical price-range boundaries.
- **Defensive Request Validation:** Strict schema validation with HTTP `400 Bad Request` rejection for missing titles, empty authors, non-numeric prices, or invalid query parameters.
- **Centralized Error Handling:** Standardized JSON error and 404 responses.
- **Debugging Suites:** Demonstrations and root-cause solutions for `EADDRINUSE`, `MODULE_NOT_FOUND`, `SQLITE_ERROR: no such table`, and missing `await` asynchronous bugs.
- **Postman Collection & Automated Tests:** 21 comprehensive test scenarios with 100% pass rate.

---

## 2. Directory Structure
```
LAB REPOORT 3/
├── package.json
├── package-lock.json
├── books.db                    (SQLite database with 10 seed books)
├── .env.example
├── .gitignore
├── README.md
├── BDF_Lab_03_Complete_Report_Appampally_Abhilash_Reddy.docx
├── BDF_Lab_03_Appampally_Abhilash_Reddy.zip
├── src/
│   ├── app.js                  (Express application configuration)
│   ├── server.js               (Server initialization & DB setup)
│   ├── database.js             (SQLite connection, schema creation & seed data)
│   ├── routes/
│   │   └── bookRoutes.js       (REST resource route definitions)
│   ├── controllers/
│   │   └── bookController.js   (CRUD business logic & SQL query builder)
│   ├── middleware/
│   │   └── errorHandler.js     (Global error & 404 not found handlers)
│   └── utils/
│       └── validation.js       (Request payload & query parameter validators)
├── tests/
│   ├── api.test.js             (Automated HTTP test runner - 21 tests)
│   └── test_results.json       (Detailed execution log)
├── postman/
│   └── BDF_Lab_03_Postman_Collection.json (Postman Collection v2.1)
├── screenshots/                (22 authentic execution screenshots)
└── debug_demos/                (Isolated reproduction scripts for 4 debug problems)
```

---

## 3. Installation & Running Instructions

### Prerequisites
- Node.js (v18.x or v24.x)
- npm (v9.x or v11.x)

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Start the REST API Server
```bash
npm start
```
The server will initialize SQLite database `books.db`, seed 10 initial sample books (if not present), and listen on:
- Base URL: `http://localhost:3000`
- API Endpoint: `http://localhost:3000/books`

### Step 3: Run Automated Test Suite
In a separate terminal or after stopping the server:
```bash
npm test
```
Executes all 21 test scenarios and produces terminal pass/fail status and saves `tests/test_results.json`.

---

## 4. API Endpoints Specification

| Method | Endpoint | Description | Query / Body Params | Status Codes |
|---|---|---|---|---|
| `GET` | `/books` | Retrieve books with filtering | `search_q`, `order_by`, `order`, `limit`, `offset`, `min_price`, `max_price` | `200`, `400` |
| `GET` | `/books/:id` | Retrieve single book | None | `200`, `400`, `404` |
| `POST` | `/books` | Create a new book | Body: `title`, `author`, `price` | `201`, `400` |
| `PUT` | `/books/:id` | Update existing book | Body: `title`, `author`, `price` | `200`, `400`, `404` |
| `DELETE` | `/books/:id` | Remove a book | None | `200`, `400`, `404` |

---

## 5. Postman Testing
1. Launch Postman.
2. Click **Import** and select `postman/BDF_Lab_03_Postman_Collection.json`.
3. Set the collection variable `baseUrl` to `http://localhost:3000`.
4. Run individual requests or run the entire collection via **Collection Runner**.

---

## 6. Debugging Demonstrations
Run each isolated demo script in `debug_demos/` to inspect specific errors:
- **EADDRINUSE:** `node debug_demos/demo_eaddrinuse.js`
- **MODULE_NOT_FOUND:** `node debug_demos/demo_wrong_path.js`
- **SQLITE_ERROR (no such table):** `node debug_demos/demo_wrong_table.js`
- **Missing Await:** `node debug_demos/demo_missing_await.js`

---

## 7. Submission Artifacts
- **Report Document:** `BDF_Lab_03_Complete_Report_Appampally_Abhilash_Reddy.docx`
- **Submission ZIP:** `BDF_Lab_03_Appampally_Abhilash_Reddy.zip`
